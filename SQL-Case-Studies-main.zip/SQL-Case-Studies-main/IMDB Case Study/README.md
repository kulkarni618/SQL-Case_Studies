# IMDB CASE STUDY

For this Case Study, I have analysed the IMDB dataset using SQL and write queries to answer some of the interesting problem statements. 
<p>The Database for this case study consists of 3 Tables -
  1. Earning
  2. Genre
  3. IMDB </p>
