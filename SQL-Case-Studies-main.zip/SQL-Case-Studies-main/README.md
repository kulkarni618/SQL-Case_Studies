# SOLVE SQL CASE STUDIES WITH ME!
<p>This repository consists of a good variety of Case study problems 
that I have encountered in my journey of learning SQL. Please check out my Solutions and Try them yourself with a different approach. </p>
<p> Happy Learning! </p>
