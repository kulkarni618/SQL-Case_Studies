# Analysis of Indian Census 2011 Data  

- These are some basic census facts - 
- Census is the process by which the information of a given population is calculated on the basis of economical, educational and social records,
in a given period of time. 
- Census is calculated after regular time intervals. In India, the census is carried out every 5 years. 
- The last census was calculated in the year 2011. This official census 2011 was the 15th census calculation which was done India.
- In this Case Study, I have analysed the data of Census 2011 for India from the website https://www.census2011.co.in/district.php and https://www.census2011.co.in/literacy.php and answered some interested questions about the Growth, literacy rate, sex ratio, area and population of India. 
